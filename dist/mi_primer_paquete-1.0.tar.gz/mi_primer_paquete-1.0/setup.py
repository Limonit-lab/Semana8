from setuptools import setup


setup(
    name="mi_primer_paquete",
    version="1.0",
    author="Semana 8",
    description="Estamos haciendo el primer paquete distribuido",
    packages=["mi_primer_paquete"]
)

